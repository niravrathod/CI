<?php
class Youraccount extends MX_Controller 
{

function __construct() {
parent::__construct();
$this->load->library('form_validation');
$this->form_validation->CI =& $this;
}

function email_submit($data=null)
{
	$this->load->module('site_security');
	if ($data!=null) {
		$data_to_receive = str_replace('-plus-', '+', $data);
	    $data_to_receive = str_replace('-fwrd-', '/', $data_to_receive);
	    $data_to_receive = str_replace('-eqls-', '=', $data_to_receive);
	    $data_to_receive = str_replace('-exc-', '!', $data_to_receive);
	    $data_to_receive = str_replace('-sp-', ' ', $data_to_receive);
	    $data_to_receive = str_replace('-dblq-', '"', $data_to_receive);
	    $data_to_receive = str_replace("-sglq-", "'", $data_to_receive);
	    $data_to_receive = str_replace('-num-', '#', $data_to_receive);
	    $data_to_receive = str_replace('-ad-', '@', $data_to_receive);
	    $data_to_receive = str_replace('-cmp-', '~', $data_to_receive);
	    $data_to_receive = str_replace('-uni-', '`', $data_to_receive);
	    $data_to_receive = str_replace('-dlr-', '$', $data_to_receive);
	    $data_to_receive = str_replace('-per-', '%', $data_to_receive);
	    $data_to_receive = str_replace('-andd-', '&', $data_to_receive);
	    $data_to_receive = str_replace('-star-', '*', $data_to_receive);
	    $data_to_receive = str_replace('-op-', '(', $data_to_receive);
	    $data_to_receive = str_replace('-cp-', ')', $data_to_receive);
	    $data_to_receive = str_replace("-undr-", '_', $data_to_receive);
	    $data_to_receive = str_replace('-line-', '|', $data_to_receive);
	    $data_to_receive = str_replace('-coma-', ',', $data_to_receive);
	    $data_to_receive = str_replace('-full-', '.', $data_to_receive);
	    $data_to_receive = str_replace('-less-', '<', $data_to_receive);
	    $data_to_receive = str_replace('-grtr-', '>', $data_to_receive);
	    $data_to_receive = str_replace('-col-', ':', $data_to_receive);
	    $data_to_receive = str_replace('-semcol-', ';', $data_to_receive);
	    $data_to_receive = str_replace('-que-', '?', $data_to_receive);
	    $data_to_receive = str_replace('-leftbr-', '[', $data_to_receive);
	    $data_to_receive = str_replace('-rightbr-', ']', $data_to_receive);
	    $data_to_receive = str_replace('-crt-', '^', $data_to_receive);



	    $data = explode(" ", $data_to_receive);
	    // print_r($data[6]);
	    // die();

		if (isset($data) && array_key_exists(6, $data) && $data[5] == $data[6]) {
		//insert username,pword,email into database

		$data_insert['username'] = $data[0];
		$data_insert['email'] = $data[1];
		$data_insert['pword'] = $data[2];
		$data_insert['repeat_pword'] = $data[3];
		$timestamp = time();
		$data_insert['date_made'] = $timestamp;

		$this->load->module('store_accounts');
		unset($data_insert['repeat_pword']);
		$pword = $data_insert['pword'];
		$this->load->module('site_security');
		$data_insert['pword'] = $this->site_security->_hash_string($pword);
		$check_email = $this->store_accounts->get_where_custom('email',$data[1]);
		$check_username = $this->store_accounts->get_where_custom('username',$data[0]);
		if ($check_email->num_rows() != null || $check_username->num_rows() != null) {
			$flash_msg = "Account Already Created, Login Now!";
		    $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
		    $this->session->set_flashdata('item',$value);
	        redirect('youraccount/login');
		}
		else{
			$this->store_accounts->_insert($data_insert);
			$this->_greetings($data_insert);
			$flash_msg = "Account Successfully Created, Login Now!";
		    $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
		    $this->session->set_flashdata('item',$value);
	        redirect('youraccount/login');
		}
		
		//$this->_process_create_account();
       
		}
		else
		{
		  $flash_msg = "OTP not matched..";
		  $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
		  $this->session->set_flashdata('item',$value);
		  redirect(base_url().'youraccount/start','refresh');
		}
	}
	else{
		$otp_data = $this->input->post('otp_encrypt',TRUE);
		$otp_encrypt = $otp_data;
	    $otp_form = $this->input->post('otp',TRUE);
	    $otp_decrypt = $this->site_security->_decrypt_string($otp_encrypt);
		if ($otp_form==$otp_decrypt) {
		$email = $this->input->post('email',TRUE);
		$username = $this->input->post('username',TRUE);
		$this->load->module('store_accounts');
		$check_email = $this->store_accounts->get_where_custom('email',$email);
		$check_username = $this->store_accounts->get_where_custom('username',$username);
		if ($check_email->num_rows() != null || $check_username->num_rows() != null) {
			$flash_msg = "Account Already Created, Login Now!";
		    $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
		    $this->session->set_flashdata('item',$value);
	        redirect('youraccount/login');
		}
		else{
		$this->_process_create_account();
        $flash_msg = "Account Successfully Created, Login Now!";
	    $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
	    $this->session->set_flashdata('item',$value);
        redirect('youraccount/login');
        }
		}
		else
		{
		  $flash_msg = "OTP not matched..";
		  $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
		  $this->session->set_flashdata('item',$value);
		  redirect(base_url().'youraccount/start','refresh');
		}
	}
	
	
	// if (isset($otp_encrypt)) {
		
	// }
	// else
	// {
	//   redirect(base_url('youraccount/start'),'refresh');
	// }
	
	
}

// function test(){
// 	// $this->load->module('site_security');
// 	// $otp = $this->site_security->generate_random_string(6);
//  //    $otp_encrypt = $this->site_security->_encrypt_string($otp);
//  //    $otp_decrypt = $this->site_security->_decrypt_string($otp_encrypt);

//  //    echo $otp;
//  //    echo "<br><hr>";
//  //    echo $otp_encrypt;
//  //    echo "<br><hr>";
//  //    echo $otp_decrypt;
// 	$timestamp = time();
// 	$this->load->module('timedate');
// 	$format = 'full';
// 	$ip_address = $_SERVER['REMOTE_ADDR'];
// 	$time  = $this->timedate->get_nice_date($timestamp,$format);
// 	echo $time;
// 	echo "<hr>";
// 	$ip = $this->input->ip_address();
// 	$location = file_get_contents('http://ip-api.com/json/49.213.46.177');
//     //print_r($location);exit;
//     $data_loc = json_decode($location);
//     echo $data_loc->timezone;


// }

function _email_verify($data)
{
	$email = $data['email'];
	$this->load->module('site_security');
    $otp = $this->site_security->generate_random_string(6);
    $otp_encrypt = $this->site_security->_encrypt_string($otp);
	$data['otp'] = $otp;
	$data['otp_encrypt'] = $otp_encrypt;
	$ci = get_instance();
	$ci->load->library('email');

	$this->email->initialize();
    $this->email->from('shopbuzz@gmx.co.uk', 'ShopBuzz Customer Support');
    $this->email->to($email); 
    $otp_token = str_replace('+', '-plus-', $otp_encrypt);
    $otp_token = str_replace('/', '-fwrd-', $otp_token);
    $otp_token = str_replace('=', '-eqls-', $otp_token);
    $data['otp_token'] = $otp_token;
    $data_to_send = implode(" ", $data);

    $data_token = str_replace('+', '-plus-', $data_to_send);
    $data_token = str_replace('/', '-fwrd-', $data_token);
    $data_token = str_replace('=', '-eqls-', $data_token);
    $data_token = str_replace('!', '-exc-', $data_token);
    $data_token = str_replace(' ', '-sp-', $data_token);
    $data_token = str_replace('"', '-dblq-', $data_token);
    $data_token = str_replace("'", '-sglq-', $data_token);
    $data_token = str_replace('#', '-num-', $data_token);
    $data_token = str_replace('@', '-ad-', $data_token);
    $data_token = str_replace('~', '-cmp-', $data_token);
    $data_token = str_replace('`', '-uni-', $data_token);
    $data_token = str_replace('$', '-dlr-', $data_token);
    $data_token = str_replace('%', '-per-', $data_token);
    $data_token = preg_replace('/\\^/', '-crt-', $data_token);
    $data_token = str_replace('&', '-andd-', $data_token);
    $data_token = str_replace('*', '-star-', $data_token);
    $data_token = str_replace('(', '-op-', $data_token);
    $data_token = str_replace(')', '-cp-', $data_token);
    // $data_token = str_replace('-', '-mn-', $data_token);
    $data_token = str_replace("_", '-undr-', $data_token);
    $data_token = str_replace('|', '-line-', $data_token);
    $data_token = str_replace(',', '-coma-', $data_token);
    $data_token = str_replace('.', '-full-', $data_token);
    $data_token = str_replace('<', '-less-', $data_token);
    $data_token = str_replace('>', '-grtr-', $data_token);
    $data_token = str_replace(':', '-col-', $data_token);
    $data_token = str_replace(';', '-semcol-', $data_token);
    $data_token = str_replace('?', '-que-', $data_token);
    $data_token = str_replace('[', '-leftbr-', $data_token);
    $data_token = str_replace(']', '-rightbr-', $data_token);
    // $data_token = str_replace('{', '-leftbrace-', $data);
    // $data_token = str_replace('}', '-rightbrace-', $data_token);

    // $data_send = implode(" ", $data_token);

    
	$form_location = base_url().'youraccount/email_submit/'.$data_token;
    $this->email->subject('ShopBuzz Email Verify');
    $this->email->message('Your OTP For ShopBuzz Email Verification: <b>'.$otp.'</b><br>You Can Verify By Clicking This Link: <a href="'.$form_location.'">VERIFY</a>');

    if ($this->email->send()) {
	 $flash_msg = "OTP sent to your email!";
     $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
     $this->session->set_flashdata('item',$value);
	     
	} else {
	   $flash_msg = "Failed to send OTP, please try again!";
	   $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
	   $this->session->set_flashdata('item',$value);
	   redirect('youraccount/start','refresh');
	}
	//$this->_otp_sent($otpdata);
	// $data['email'] = $email;
	// $data['username'] = $this->input->post('username',TRUE);
	// $data['pword'] = $this->input->post('pword',TRUE);

	$data['flash'] = $this->session->flashdata('item');
	$data['view_file'] = "email_verify";
	$this->load->module('templates');
	$this->templates->public_bootstrap($data); 
	    
}

public function _sendpassword($email)
{
    $this->load->module('site_security');
    $query_pass = "SELECT *  from store_accounts where email = ? ";
	$query1 = $this->db->query($query_pass,array($email));
    foreach ($query1->result() as $row) {
    	$username = $row->username;
    }
        
    if ($query1->num_rows()>0)   
	{
    $passwordplain  = $this->site_security->generate_random_string(10);
    $newpass = $this->site_security->_hash_string($passwordplain);
    $query2 = "UPDATE store_accounts SET pword=? WHERE email=?";
    $this->db->query($query2,array($newpass,$email));
    $ci = get_instance();
	$ci->load->library('email');   

    $this->email->initialize();
    $this->email->from('shopbuzz@gmx.co.uk', 'ShopBuzz Customer Support');
    $this->email->to($email); 

    $this->email->subject('New Password From ShopBuzz');
    $this->email->message('Dear '.$username.','. "\r\n".'Thanks for contacting regarding to forgot password,<br><br> Your Password is <b>'.$passwordplain.'</b>'."\r\n".'<br><br>Please Update your password.'.'<br><br>Thanks.<br><br>ShopBuzz™');
	if ($this->email->send()) {
		 $flash_msg = "Password sent to your email!";
	     $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
	     $this->session->set_flashdata('item',$value);
	     
	} else {
	   $flash_msg = "Failed to send password, please try again!";
	   $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
	   $this->session->set_flashdata('item',$value);
	}
	  redirect(base_url().'youraccount/login','refresh');        
	}
	else
	{  
	  $flash_msg = "Email not found try again!";
	  $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
	  $this->session->set_flashdata('item',$value);
	  redirect(base_url().'youraccount/login','refresh');
	}
}

function Password_recovery()
{   
    $data['flash'] = $this->session->flashdata('item');
    $data['email'] = $this->input->post('email',TRUE);
    $data['view_file'] = "forgot_password";
    $this->load->module('templates');
    $this->templates->public_bootstrap($data);
}

function otp_submit()
{
	$this->load->module('site_security');

	$otp_form = $this->input->post('otp',TRUE);
	$otp_encrypt = $this->input->post('otp_encrypt',TRUE);
	$otp = $this->site_security->_decrypt_string($otp_encrypt);
	if ($otp_form==$otp) {
		$email = $this->input->post('email', TRUE);
		$this->_sendpassword($email);
	}
	else
	{
	  $flash_msg = "OTP not matched..";
	  $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
	  $this->session->set_flashdata('item',$value);
	  redirect(base_url().'youraccount/login','refresh');
	}
	
}

function _otp_send($emaildata)
{
	$this->load->module('site_security');
	if ($emaildata->num_rows()>0)   
	{

		foreach ($emaildata->result() as $row) {
	    	$email = $row->email;
	    }
	    $data['email'] = $email;
	    $otp = $this->site_security->generate_random_string(6);
	    $otp_encrypt = $this->site_security->_encrypt_string($otp);
    	$data['otp_encrypt'] = $otp_encrypt;
		// $data['otp'] = $otp;
		$ci = get_instance();
		$ci->load->library('email');

		$this->email->initialize();
	    $this->email->from('shopbuzz@gmx.co.uk', 'ShopBuzz Customer Support');
	    $this->email->to($email); 

	    $this->email->subject('OTP From ShopBuzz');
	    $this->email->message('Your OTP For ShopBuzz Password Recovery: <b>'.$otp.'</b>');

	    if ($this->email->send()) {
		 $flash_msg = "OTP sent to your email!";
	     $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
	     $this->session->set_flashdata('item',$value);
	     
		} else {
		   $flash_msg = "Failed to send OTP, please try again!";
		   $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
		   $this->session->set_flashdata('item',$value);
		   redirect('youraccount/password_recovery','refresh');
		}
		  //$this->_otp_sent($otpdata);
		  $data['flash'] = $this->session->flashdata('item');
		  $data['view_file'] = "otp_confirm";
	      $this->load->module('templates');
	      $this->templates->public_bootstrap($data); 
	    
	}
	else
	{
	  $flash_msg = "Email not found try again!";
	  $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
	  $this->session->set_flashdata('item',$value);
	  redirect(base_url().'youraccount/login','refresh');
	}
}

function ForgotPassword()
{
    $this->load->module('store_accounts');
    $email = $this->input->post('email',TRUE);      
    $findemail = $this->store_accounts->get_where_custom('email',$email);
    $num_rows = $findemail->num_rows();  
    if($num_rows != null)
    {
      $this->_otp_send($findemail);

      //$this->sendpassword($findemail);        
    }
    else
    {
      $flash_msg = "Email not found!";
	  $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
	  $this->session->set_flashdata('item',$value);
      redirect(base_url().'youraccount/login','refresh');
  	}
}

function logout()
{
	unset($_SESSION['user_id']);
	$this->load->module('site_cookies');
	$this->site_cookies->_destroy_cookie();
	redirect(base_url());
}

function welcome()
{
	$this->load->module('site_security');
	$this->site_security->_make_sure_logged_in();
	$data['flash'] = $this->session->flashdata('item');
    $data['view_file'] = "welcome";
    $this->load->module('templates');
    $this->templates->public_bootstrap($data);
}

function login()
{
	$data['flash'] = $this->session->flashdata('item');
	$data['username'] = $this->input->post('username', TRUE);
    $this->load->module('templates');
    $this->templates->login($data);
}

function submit_login()
{
	  $this->load->module('site_security');
	  $this->load->module('store_accounts');
	  $submit = $this->input->post('submit',TRUE);
	  $firstname = trim($this->input->post('firstname', TRUE)); //hidden var!

      if ($firstname!='') 
      {
          $this->_blacklist_user();//must be a bot!
      }
	  
	  if ($submit=="Submit") {
        //process the form
	    $this->load->library('form_validation');
	    $this->form_validation->set_rules('username','Username','required|min_length[5]|max_length[60]|callback_username_check');
	    $this->form_validation->set_rules('pword','Password','required|min_length[7]|max_length[35]');
	    if ($this->form_validation->run()==TRUE) {
	        //figure out user_id
		    $col1 = 'username';
		    $value1 = $this->input->post('username', TRUE);
		    $col2 = 'email';
		    $value2 = $this->input->post('username', TRUE);
		    $query = $this->store_accounts->get_with_double_condition($col1, $value1, $col2, $value2);
		    foreach ($query->result() as $row) {
		    	$user_id = $row->id;
		    }
		    //user is active or not
		 	$query = $this->store_accounts->get_where_custom('id',$user_id);
	    	if ($query->num_rows() != null) {
	    		$row = $query->row();
	    		if ($row->status != 1) {
	    			$flash_msg = "Account Is Not Active, Contact Us For More Details.";
				    $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
				    $this->session->set_flashdata('item',$value);
			        redirect('youraccount/login');
	    		}
	    	}
		    $data['last_login'] = time();
		    $this->store_accounts->_update($user_id, $data);
		    //send them to the private page
	        


		    $remember = $this->input->post('remember', TRUE);
		    if ($remember=="remember-me") {
		    	$login_type = "longterm";
		    }
		    else
		    {
		    	$login_type = "shortterm";
		    }
		    $this->_in_you_go($user_id, $login_type);

	    	
	    }
	    else
	    {
	    	echo validation_errors('<p style="color:red;">','</p>');
	    }
    }
}

function _in_you_go($user_id, $login_type)
{
	//NOTE: the login_type can be longterm or shortterm
	if($login_type=="longterm") {
		//set a cookie
		// $this->load->helper('cookie');
		// $this->input->set_cookie($user_id);
		$this->load->module('site_cookies');
		$this->site_cookies->_set_cookie($user_id);

		
	}
	else
	{
		//set a session variable
		$this->session->set_userdata('user_id', $user_id);
	}

	//attempt to update cart and divert to cart
	$this->_attempt_cart_divert($user_id);
	
	//send the user to the private page
	redirect('youraccount/welcome');
}

function _attempt_cart_divert($user_id)
{
	$this->load->module('store_basket');
	$customer_session_id = $this->session->session_id;

	$col1 = 'session_id';
	$value1 = $customer_session_id;
	$col2 = 'shopper_id';
	$value2 = 0;
	$query = $this->store_basket->get_with_double_condition($col1, $value1, $col2, $value2);
	$num_rows = $query->num_rows();
	if ($num_rows>0) {
		//There is record that need corrected
		$mysql_query = "update store_basket set shopper_id=$user_id where session_id='$customer_session_id'";
		$query = $this->store_basket->_custom_query($mysql_query);
		redirect('cart');
	}
}

function submit()
{
	  $submit = $this->input->post('submit',TRUE);
	  $firstname = trim($this->input->post('firstname', TRUE)); //hidden var!

      if ($firstname!='') 
      {
          $this->_blacklist_user();//must be a bot!
      }
	  if ($submit=="Submit") {
        //process the form
	    $this->load->library('form_validation');
	    $this->form_validation->set_rules('username','Username','required|min_length[5]|max_length[60]|is_unique[store_accounts.username]');
    	$this->form_validation->set_rules('email','Email','required|valid_email|max_length[60]|is_unique[store_accounts.email]');
	    $this->form_validation->set_rules('pword','Password','required|min_length[7]|max_length[35]');
	    $this->form_validation->set_rules('repeat_pword','Repeat Password','required|matches[pword]');
	    if ($this->form_validation->run()==TRUE) {
	        //get the variables
	        // echo "well done";
	        $data = $this->fetch_data_from_post();
	        // $email = $data['email'];
	        $this->_email_verify($data);
        
	    }
	    else
	    {
	    	echo $this->start();
	    	
	    }
    }
}

function _greetings($posted_data)
{

	$this->load->module('enquiries');
	$this->load->module('site_security');
	$email = $posted_data['email'];
	$query = $this->store_accounts->get_where_custom('email',$email);
    foreach ($query->result() as $row) {
        $subject_username = $row->username;
        $new_user_id = $row->id;
    }

    //build a message for the customer
    $msg = 'Purchase Your Favorite Smartphones From <b>ShopBuzz</b>, Hope You Will Enjoy Buying.';
    $msg.= '<br>Regards,<br> <b>ShopBuzz TEAM</b>';

    //send the message to customer from enquiries module
    $data['subject'] = ucfirst($subject_username).' Welcome To ShopBuzz!';
    $data['message'] = $msg;
    $data['sent_to'] = $new_user_id;
    $data['date_created'] = time();
    $data['sent_by'] = 0; //admin
    $data['opened'] = 0; //not opened
    $data['code'] = $this->site_security->generate_random_string(6);
    $this->enquiries->_insert($data);
}

function _process_create_account()
{
	$this->load->module('store_accounts');
	$data = $this->fetch_data_from_post();
	unset($data['repeat_pword']);
	$pword = $data['pword'];
	$this->load->module('site_security');
	$data['pword'] = $this->site_security->_hash_string($pword);
	$timestamp = time();
	$data['date_made'] = $timestamp;
	$this->store_accounts->_insert($data);
	$this->_greetings($data);
}

function start()
{
	$data = $this->fetch_data_from_post();
	$data['flash'] = $this->session->flashdata('item');
    $data['view_file'] = "start";
    $this->load->module('templates');
    $this->templates->public_bootstrap($data);
}

function fetch_data_from_post()
{
	$data['username'] = $this->input->post('username',TRUE);
	$data['email'] = $this->input->post('email',TRUE);
	$data['pword'] = $this->input->post('pword',TRUE);
	$data['repeat_pword'] = $this->input->post('repeat_pword',TRUE);
	return $data;
}

function username_check($str)
{
    $this->load->module('site_security');
    $this->load->module('store_accounts');
    $error_msg = "You did not enter a correct username and/or password.";

    $col1 = 'username';
    $value1 = $str;
    $col2 = 'email';
    $value2 = $str;
    $query = $this->store_accounts->get_with_double_condition($col1, $value1, $col2, $value2);
    $num_rows = $query->num_rows();

    if ($num_rows<1) {
    	$this->form_validation->set_message('username_check', $error_msg);
        return FALSE;
    }

    foreach ($query->result() as $row) {
    	$pword_on_table = $row->pword;
    }
    $pword = $this->input->post('pword', TRUE);
    $result = $this->site_security->_verify_hash($pword, $pword_on_table);

    if ($result==TRUE) {
    	return TRUE;
    }
    else
    {
    	$this->form_validation->set_message('username_check', $error_msg);
        return FALSE;
    }

}

function _blacklist_user()
{
    $this->load->module('blacklist');
    $data['ip_address'] = $this->input->ip_address();
    $data['date_created'] = time();
    $this->blacklist->_insert($data);
    redirect('site_security/not_allowed');
    return FALSE;
}

// function test() for getting last_six_chars from hashed_name
// {
// 	$name = "Nirav";
// 	$this->load->module('site_security');
// 	$hashed_name = $this->site_security->_hash_string($name);
// 	echo "Name is $name<br>";
// 	echo "$hashed_name";
// 	echo "<hr>";

// 	$hashed_name_length = strlen($hashed_name);
// 	$start_point = $hashed_name_length-6;
// 	$last_six_chars = substr($hashed_name, $start_point, 6);
// 	echo $last_six_chars;
// }

}