<style type="text/css">
  .name {
    display: none;
}
  
</style>
<?php 
$form_location = base_url().'youraccount/otp_submit/';
// echo validation_errors("<p style='color: red;'>","</p>");
if (isset($flash)) {
	echo $flash;
}
?>

<h1>Recover Account Password</h1>
<?php
echo validation_errors("<p style='color: red;'>","</p>");
?>
<form class="form-horizontal" action="<?= $form_location ?>" method="post">
<fieldset>

<!-- Form Name -->
<legend>Please enter your OTP using the form below</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">OTP</label>  
  <div class="col-md-4">
  <input id="textinput" name="otp" type="text" placeholder="Enter your OTP sended to your email" class="form-control input-md" required="">
  <!-- <?= form_error('username',"<p style='color: red;'>","</p>") ?> -->
  </div>
</div>
<input type="hidden" name="email" value="<?= $email?>">
<input type="hidden" name="otp_encrypt" value="<?= $otp_encrypt?>">
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button name="submit" value="Submit" class="btn btn-primary">Confirm</button>
  </div>
</div>

</fieldset>
</form>
