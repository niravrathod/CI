<style type="text/css">
  .name {
    display: none;
}
  
</style>

<?php 
$form_location = base_url().'youraccount/email_submit/';
// echo validation_errors("<p style='color: red;'>","</p>");
if (isset($flash)) {
	echo $flash;
}

?>
<?php
echo validation_errors("<p style='color: red;'>","</p>");
?>
<div class="container be-detail-container">
    <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
            <br>
            <img src="https://cdn2.iconfinder.com/data/icons/luchesa-part-3/128/SMS-512.png" class="img-responsive" style="width:100px; height:100px;margin:0 auto;"><br>
            
            <h1 class="text-center">Verify your email address</h1><br>
            <p class="lead" style="align:center"></p><p> Thanks for registration. An OTP has been sent to your email address (<b><?= $email ?></b>). Please enter the OTP below for Successful Registration.</p>  <p></p>
        <br>
       
            <form action="<?= $form_location ?>" method="post" id="veryfyotp" autocomplete="off">
                <div class="row">                    
                <div class="form-group col-sm-8">
                   <span style="color:red;"></span>                    <input type="text" class="form-control" name="otp" placeholder="Enter your OTP here" required="">
                </div>
                <input type="hidden" name="email" value="<?= $email?>">
                <input type="hidden" name="username" value="<?= $username?>">
                <input type="hidden" name="pword" value="<?= $pword?>">
                <input type="hidden" name="otp_encrypt" value="<?= $otp_encrypt?>">
                <button type="submit" value="Submit" class="btn btn-primary  pull-left col-sm-2">Verify</button>
                <!-- <button type="button" id="resend" value="Resend" class="btn btn-default  pull-left col-sm-2">Resend</button> -->
                </div>
            </form>
        <br><br>
        </div>
    </div>        
</div>

<script type="text/javascript">
  $(document).ready(function{
      $('#resend').hide();
  });
</script>


