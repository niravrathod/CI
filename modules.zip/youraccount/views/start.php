<style type="text/css">
  .name {
    display: none;
}
  
</style>
<?php 
$form_location = base_url().'youraccount/submit';
// echo validation_errors("<p style='color: red;'>","</p>");
if (isset($flash)) {
  echo $flash;
}
?>

<h1>Create Account</h1>
<?php
echo validation_errors("<p style='color: red;'>","</p>");
?>
<form class="form-horizontal" action="<?= $form_location ?>" method="post" autocomplete="off">
<fieldset>

<!-- Form Name -->
<legend>Please submit your details using the form below</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Username</label>  
  <div class="col-md-4">
  <input id="textinput" name="username" type="text" value="<?= $username ?>" placeholder="Enter your username" class="form-control input-md" required="">
  <!-- <?= form_error('username',"<p style='color: red;'>","</p>") ?> -->
  </div>
</div>

<div class="form-group name">
  <label for="name">
      Name</label>
  <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Enter name"/>
</div>


<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">E-mail</label>  
  <div class="col-md-4">
  <input id="textinput" name="email" type="text" value="<?= $email ?>" placeholder="Enter your contact email address" class="form-control input-md">
  <!-- <?= form_error('email',"<p style='color: red;'>","</p>") ?> -->
  </div>
</div>

<!-- Text input
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Security Question</label>  
  <div class="col-md-4">
  <select name="securityque" id="inputState" class="form-control">
        <option value="What is the name of your dog?">What is the name of your dog?</option>
        <option value="What is the name of your favorite teacher?">What is the name of your favorite teacher?</option>
        <option value="What is your maiden name?">What is your maiden name?</option>
        <option value="In what city were you born?">In what city were you born?</option>
        <option value="What is your favorite food?">What is your favorite food?</option>
                   
      </select>
  <?= form_error('email',"<p style='color: red;'>","</p>") ?>
  </div>
</div>

Text input
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Security Answer</label>  
  <div class="col-md-4">
  <input id="textinput" name="securityans" type="text" value="<?= 'securityans' ?>" placeholder="Enter your security answer" class="form-control input-md">
  <?= form_error('email',"<p style='color: red;'>","</p>") ?>
  </div>
</div> -->

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Password</label>  
  <div class="col-md-4">
  <input id="textinput" name="pword" type="password" value="<?= $pword ?>" placeholder="Enter your password" class="form-control input-md">
  <!-- <?= form_error('pword',"<p style='color: red;'>","</p>") ?> -->
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Repeat Password</label>  
  <div class="col-md-4">
  <input id="textinput" name="repeat_pword" type="password" value="<?= $repeat_pword ?>" placeholder="Re-Enter your password" class="form-control input-md">
  <!-- <?= form_error('repeat_pword',"<p style='color: red;'>","</p>") ?> -->
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton">Create Account?</label>
  <div class="col-md-4">
    <button id="singlebutton" name="submit" value="Submit" class="btn btn-primary">Yes</button>
  </div>
</div>

</fieldset>
</form>
