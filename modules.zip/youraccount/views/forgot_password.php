<style type="text/css">
  .name {
    display: none;
}
  
</style>
<?php 
$form_location = base_url().'youraccount/forgotpassword';
// echo validation_errors("<p style='color: red;'>","</p>");
if (isset($flash)) {
  echo $flash;
}
?>

<h1>Recover Account Password</h1>
<?php
echo validation_errors("<p style='color: red;'>","</p>");
?>
<form class="form-horizontal" action="<?= $form_location ?>" method="post">
<fieldset>

<!-- Form Name -->
<legend>Please enter your email using the form below</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Email</label>  
  <div class="col-md-4">
  <input id="textinput" name="email" type="text" placeholder="Enter your email address" class="form-control input-md" required="">
  <!-- <?= form_error('username',"<p style='color: red;'>","</p>") ?> -->
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button name="submit" value="Submit" class="btn btn-primary">Recover</button>
  </div>
</div>

</fieldset>
</form>

